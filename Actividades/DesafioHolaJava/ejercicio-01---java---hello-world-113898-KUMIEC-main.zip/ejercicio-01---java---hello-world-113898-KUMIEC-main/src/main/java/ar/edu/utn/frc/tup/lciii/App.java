package ar.edu.utn.frc.tup.lciii;

/**
 * Hello Java!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        /* Enter your code here. Print output to STDOUT. Your class should be named Solution. */

    }
}
